package com.parking.Model.Services;

import org.springframework.stereotype.Service;

import com.parking.Model.Services.Contract.MarketingService;

@Service
public class MarketingServiceImp implements MarketingService {

	@Override
	public void replyNewsletterPromotionalPage() {
		// TODO Auto-generated method stub
		
	}

}
