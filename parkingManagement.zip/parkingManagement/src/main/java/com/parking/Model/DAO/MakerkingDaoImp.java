package com.parking.Model.DAO;

import org.springframework.stereotype.Repository;

import com.parking.Model.DAO.Contract.MarketingDao;
import com.parking.common.BaseDao;
@Repository
public class MakerkingDaoImp  extends BaseDao implements MarketingDao{

}
