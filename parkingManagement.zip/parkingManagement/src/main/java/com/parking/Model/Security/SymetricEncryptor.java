package com.parking.Model.Security;

public class SymetricEncryptor implements Encryptor {

	@Override
	public byte[] encrypt(String text, String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String decrypt(String text, String key) {
		// TODO Auto-generated method stub
		return null;
	}

 

 

}
