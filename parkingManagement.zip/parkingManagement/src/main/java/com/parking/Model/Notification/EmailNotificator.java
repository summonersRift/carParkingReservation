package com.parking.Model.Notification;

import com.parking.Model.Notification.Contract.Notificator;

public class EmailNotificator implements Notificator {

	@Override
	public void notifyUSer() {
		// TODO Auto-generated method stub
		
	}





}
