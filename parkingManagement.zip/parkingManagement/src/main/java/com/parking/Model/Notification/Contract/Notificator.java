package com.parking.Model.Notification.Contract;

public interface Notificator {

	void notifyUSer(); 
	

}
