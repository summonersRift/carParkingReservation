package com.parking.Model.Domain;

public class MarketingNewsletterPromotional {
	private String Message;
	private String promo;

	public String getPromo() {
		return promo;
	}

	public void setPromo(String promo) {
		this.promo = promo;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

}
