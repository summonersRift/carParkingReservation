package com.parking.Model.DAO.Contract;

public interface MarketingDao {

}
