package com.parking.Model.Services.Contract;

public interface MarketingService {

	void replyNewsletterPromotionalPage();

}
