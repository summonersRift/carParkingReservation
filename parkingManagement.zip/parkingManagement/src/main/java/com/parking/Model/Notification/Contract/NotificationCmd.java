package com.parking.Model.Notification.Contract;

public interface NotificationCmd {
                                              
	void execute() throws Exception;

}
