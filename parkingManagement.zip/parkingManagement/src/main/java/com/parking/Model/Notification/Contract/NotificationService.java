package com.parking.Model.Notification.Contract;

public interface NotificationService {

	public Boolean validateRequest();

	public void ProcessRequest();

}
