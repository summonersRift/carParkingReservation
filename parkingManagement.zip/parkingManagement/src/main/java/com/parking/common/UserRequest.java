package com.parking.common;

public class UserRequest {

}
