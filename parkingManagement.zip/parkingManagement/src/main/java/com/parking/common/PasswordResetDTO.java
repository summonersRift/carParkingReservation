package com.parking.common;

public class PasswordResetDTO {

}
